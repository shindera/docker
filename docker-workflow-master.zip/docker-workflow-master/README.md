# A sample Docker workflow with Node.js, Redis and NGiNX

[![Circle CI](https://circleci.com/gh/msanand/docker-workflow/tree/master.svg?style=shield)](https://circleci.com/gh/msanand/docker-workflow/tree/master)

For a detailed explanation of the workflow used in this repository, refer to [this post from my blog](http://anandmanisankar.com/posts/docker-container-nginx-node-redis-example/):
[http://anandmanisankar.com/posts/docker-container-nginx-node-redis-example/](http://anandmanisankar.com/posts/docker-container-nginx-node-redis-example/)

For a detailed overview of Containers and Docker, refer to [this post from my blog](http://anandmanisankar.com/posts/container-docker-PaaS-microservices/):
[http://anandmanisankar.com/posts/container-docker-PaaS-microservices/](http://anandmanisankar.com/posts/container-docker-PaaS-microservices/)


